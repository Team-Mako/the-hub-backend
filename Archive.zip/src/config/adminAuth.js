export default {
  secret: 'teamMakoAdmin',
  expiresIn: '1d',
};
