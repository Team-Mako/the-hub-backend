export default {
  secret: 'teamMako',
  expiresIn: '7d',
};
