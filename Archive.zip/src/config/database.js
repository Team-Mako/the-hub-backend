export default {
  host: 'localhost',
  user: 'thehubadm',
  password: 'Y?rq24c8',
  database: 'thehub',
};

// Remote User: thehubadm
// Remote Pass: 8z%bS6e1
